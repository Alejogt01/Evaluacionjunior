﻿using EvaluacionJunior.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EvaluacionJunior.ViewModels
{
    /// <summary>
    /// ViewModel que contiene los datos necesarios para la vista de productos filtrados por categoría.
    /// </summary>
    public class ProductosViewModel
    {
        /// <summary>
        /// Código de la categoría que seleccionó el usuario.
        /// </summary>
        public int? CodigoCategoria { get; set; }

        /// <summary>
        /// Lista de categorías disponibles que tuvieron ventas en 2019.
        /// Este se utiliza para llenar el menú desplegable en la vista.
        /// </summary>
        public List<SelectListItem> Categorias { get; set; } = new();

        /// <summary>
        /// Lista de productos vendidos en 2019 según la categoría seleccionada.
        /// </summary>
        public List<Producto> Productos { get; set; } = new();
    }
}
