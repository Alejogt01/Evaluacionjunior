﻿using System;
using System.Collections.Generic;

namespace EvaluacionJunior.Models;

/// <summary>
/// Representa una categoría de productos.
/// </summary>
public partial class Categorium
{
    /// <summary>
    /// PK de la categoría.
    /// </summary>
    public int CodigoCategoria { get; set; }

    /// <summary>
    /// Nombre de la categoría.
    /// </summary>
    public string Nombre { get; set; } = null!;

    /// <summary>
    /// Colección de productos que pertenecen a esta categoría.
    /// </summary>
    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
