﻿using System;
using System.Collections.Generic;

namespace EvaluacionJunior.Models;


/// <summary>
/// Representa un producto del sistema.
/// </summary>

public partial class Producto
{
   
    /// <summary>
    /// Clave primaria del producto.
    /// </summary>
  
    public int CodigoProducto { get; set; }

    /// <summary>
    /// Nombre del producto.
    /// </summary>
  
    public string Nombre { get; set; } = null!;

   
    /// <summary>
    /// Clave foránea que indica a qué categoría pertenece este producto.
    /// </summary>

    public int CodigoCategoria { get; set; }


    /// <summary>
    /// Navegación hacia la categoría asociada.
    /// </summary>

    public virtual Categorium CodigoCategoriaNavigation { get; set; } = null!;

 
    /// <summary>
    /// Colección de ventas en las que este producto ha sido vendido.
    /// </summary>
  
    public virtual ICollection<Ventum> Ventas { get; set; } = new List<Ventum>();
}
