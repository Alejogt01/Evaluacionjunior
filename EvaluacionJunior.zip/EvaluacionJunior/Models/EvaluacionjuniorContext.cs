﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EvaluacionJunior.Models;

public partial class EvaluacionjuniorContext : DbContext
{
    public EvaluacionjuniorContext()
    {
    }

    public EvaluacionjuniorContext(DbContextOptions<EvaluacionjuniorContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Categorium> Categoria { get; set; }

    public virtual DbSet<Producto> Productos { get; set; }

    public virtual DbSet<Ventum> Venta { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    { 
    
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=LAPTOP-ACQBC90E\\SQLEXPRESS;Database=EVALUACIONJUNIOR;Trusted_Connection=True;TrustServerCertificate=True;");
    }
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Categorium>(entity =>
        {
            
            entity.HasKey(e => e.CodigoCategoria).HasName("PK__CATEGORI__3CEE2F4C61FFD540");

            entity.ToTable("CATEGORIA");

            entity.Property(e => e.CodigoCategoria).ValueGeneratedNever();
            entity.Property(e => e.Nombre).HasMaxLength(100);
        });

        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.CodigoProducto).HasName("PK__PRODUCTO__785B009ECFEB16F1");

            entity.ToTable("PRODUCTO");

            entity.Property(e => e.Nombre).HasMaxLength(100);

            entity.HasOne(d => d.CodigoCategoriaNavigation).WithMany(p => p.Productos)
                .HasForeignKey(d => d.CodigoCategoria)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PRODUCTO__Codigo__4BAC3F29");
        });

        modelBuilder.Entity<Ventum>(entity =>
        {
            entity.HasKey(e => e.CodigoVenta).HasName("PK__VENTA__F2421464E9F65989");

            entity.ToTable("VENTA");

            entity.Property(e => e.Fecha)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime");

            entity.HasOne(d => d.CodigoProductoNavigation).WithMany(p => p.Ventas)
                .HasForeignKey(d => d.CodigoProducto)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__VENTA__CodigoPro__4F7CD00D");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
