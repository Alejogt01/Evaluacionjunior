﻿using System;

namespace EvaluacionJunior.Models;

/// <summary>
/// Representa una venta de un producto.
/// </summary>
public partial class Ventum
{
    /// <summary>
    /// PK de la venta.
    /// </summary>
    public int CodigoVenta { get; set; }

    /// <summary>
    /// Fecha de la venta.
    /// </summary>
    public DateTime Fecha { get; set; } = DateTime.Now;

    /// <summary>
    /// FK que indica qué producto fue vendido.
    /// </summary>
    public int CodigoProducto { get; set; }

    /// <summary>
    /// Navegación hacia el producto asociado a esta venta.
    /// </summary>
    public Producto CodigoProductoNavigation { get; set; } = null!;
}
