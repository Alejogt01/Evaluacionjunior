﻿using EvaluacionJunior.Models;
using EvaluacionJunior.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

//Controlador que se encarga de mostrar las ventas del 2019 y los filtra por categoría
public class ProductosController : Controller
{ //Constructor del controlador que recibe la BD con una inyección
    private readonly EvaluacionjuniorContext _context;

    public ProductosController(EvaluacionjuniorContext context) //Contexto de la BD
    {
        _context = context;
    }

    public IActionResult Index(int? CodigoCategoria) //Vista del listado de los productos que se filtran    
    {
        //Se definen el rango que filtran las ventas del 2019
        var fechaInicio = new DateTime(2019, 1, 1);
        var fechaFin = new DateTime(2020, 1, 1);

        //Aqui se obtienen las categorias que se vendieron en el 2019
        var categorias = _context.Categoria
            .Where(c => c.Productos.Any(p =>
                p.Ventas.Any(v => v.Fecha >= fechaInicio && v.Fecha < fechaFin)))
            .Select(c => new SelectListItem
            {
                Value = c.CodigoCategoria.ToString(),
                Text = c.Nombre
            })
            .ToList();

        //Inicia la lista de productos y está vacía por defecto
        var productos = new List<Producto>();

        //Condición de que si el usuario selecciona una categoria le filtre las ventas del 2019
        if (CodigoCategoria.HasValue)
        {
            productos = _context.Productos
                .Include(p => p.Ventas)
                .Where(p => p.CodigoCategoria == CodigoCategoria &&
                            p.Ventas.Any(v => v.Fecha >= fechaInicio && v.Fecha < fechaFin))
                .ToList();
        }

        //Se construye el ViewModel que se enviará a la vista
        var viewModel = new ProductosViewModel
        {
            CodigoCategoria = CodigoCategoria,
            Categorias = categorias,
            Productos = productos
        };

        //Retorna la vista con datos cargados
        return View(viewModel);
    }
}
